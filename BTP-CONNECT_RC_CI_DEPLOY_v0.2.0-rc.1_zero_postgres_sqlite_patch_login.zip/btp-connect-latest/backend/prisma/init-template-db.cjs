/*
  Create/refresh the SQLite template DB used by the packaged Electron app.
  - Uses local Prisma CLI from node_modules.
  - Writes: backend/prisma/btpconnect.template.db

  Usage:
    npm run prisma:init-template
*/

const { spawnSync } = require('child_process');
const path = require('path');
const fs = require('fs');

const backendDir = path.resolve(__dirname, '..');
const prismaDir = path.resolve(backendDir, 'prisma');
const templateDb = path.resolve(prismaDir, 'btpconnect.template.db');

// Ensure prisma dir exists
fs.mkdirSync(prismaDir, { recursive: true });

// Remove previous template to guarantee schema refresh
if (fs.existsSync(templateDb)) {
  fs.rmSync(templateDb, { force: true });
}

// Prisma CLI path (works cross-platform)
const prismaBin = process.platform === 'win32'
  ? path.resolve(backendDir, 'node_modules', '.bin', 'prisma.cmd')
  : path.resolve(backendDir, 'node_modules', '.bin', 'prisma');

if (!fs.existsSync(prismaBin)) {
  console.error('[prisma:init-template] Prisma CLI not found. Run: npm ci');
  process.exit(1);
}

const env = {
  ...process.env,
  // IMPORTANT: use a relative file in prisma/ for creation
  DATABASE_URL: 'file:./prisma/btpconnect.template.db',
};

console.log('[prisma:init-template] Creating SQLite template DB via: prisma db push');
const r = spawnSync(prismaBin, ['db', 'push'], {
  cwd: backendDir,
  env,
  stdio: 'inherit',
});

process.exit(r.status ?? 1);
