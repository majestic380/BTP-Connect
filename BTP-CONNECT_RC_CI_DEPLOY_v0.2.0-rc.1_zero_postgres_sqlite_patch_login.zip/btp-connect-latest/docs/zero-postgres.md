# Zero-Postgres (SQLite embarqué)

## Principe
- Le backend utilise Prisma + SQLite.
- En Electron packagé, la base est stockée dans le dossier **userData** (writable), pas dans `resources`.
- Au premier démarrage, l'app copie un template DB (`backend/prisma/btpconnect.template.db`) vers:
  - `userData/data/btpconnect.db`

## Build Windows (EXE)
```powershell
Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process
.\scripts\build-win-standalone.ps1
```
- Le script crée/rafraîchit le template DB via `prisma db push`.

## Tests (agent vérificateur)
```powershell
Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process
.\qa\agent_verificateur_zero_postgres.ps1
```
