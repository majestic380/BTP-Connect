# Release vX.Y.Z – BTP Connect

## Nouveautés
- 

## Correctifs
- 

## Sécurité
- 

## Notes de déploiement
- Desktop standalone: local/LAN/cloud
- PWA iOS: HTTPS requis

## Checksums
- Voir `CHECKSUMS.sha256`
