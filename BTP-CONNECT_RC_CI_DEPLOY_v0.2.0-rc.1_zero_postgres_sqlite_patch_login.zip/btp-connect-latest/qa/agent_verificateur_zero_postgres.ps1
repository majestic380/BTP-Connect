# BTP Connect - Agent vérificateur (zero-postgres)
# Objectif: tests rapides en config opérationnelle (backend + UI) sans PostgreSQL
# Usage:
#   Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process
#   .\qa\agent_verificateur_zero_postgres.ps1

$ErrorActionPreference = "Stop"

function Assert-Ok($cond, $msg) {
  if (-not $cond) { throw "[FAIL] $msg" }
  Write-Host "[OK] $msg" -ForegroundColor Green
}

Write-Host "[1/5] Tests backend (SQLite)" -ForegroundColor Cyan
Push-Location "backend"
  npm ci
  npm run prisma:generate
  npm run prisma:init-template
  npm run build

  $env:PORT = "3100"
  $env:HOST = "127.0.0.1"
  $env:DATABASE_URL = "file:./prisma/qa.db"

  Write-Host "Starting backend on http://127.0.0.1:3100 ..." -ForegroundColor DarkGray
  $p = Start-Process -FilePath "node" -ArgumentList "dist/server.js" -PassThru -WindowStyle Hidden
  Start-Sleep -Seconds 2

  try {
    $r1 = Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:3100/health" -TimeoutSec 10
    Assert-Ok ($r1.StatusCode -eq 200) "GET /health retourne 200"

    $r2 = Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:3100/admin-ui" -TimeoutSec 10
    Assert-Ok ($r2.StatusCode -eq 200) "GET /admin-ui retourne 200"
    Assert-Ok ($r2.Content -match "BTP") "admin-ui contient du HTML"
  } finally {
    if ($p -and -not $p.HasExited) {
      Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue
    }
  }
Pop-Location

Write-Host "[2/5] Smoke test UI (fichiers)" -ForegroundColor Cyan
Assert-Ok (Test-Path ".\src\index.html") "src/index.html présent"

Write-Host "[3/5] Build Windows standalone (EXE)" -ForegroundColor Cyan
.\scripts\build-win-standalone.ps1

Write-Host "[4/5] Vérification artefacts" -ForegroundColor Cyan
$exes = Get-ChildItem -Path "dist" -Recurse -Filter "*.exe" -ErrorAction SilentlyContinue
Assert-Ok ($exes.Count -ge 1) "Au moins 1 .exe généré dans dist"

Write-Host "[5/5] FIN" -ForegroundColor Green
