# BTP Connect - Build Windows standalone (EXE)
# Usage (PowerShell):
#   Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process
#   .\scripts\build-win-standalone.ps1

$ErrorActionPreference = "Stop"

function Assert-Command($name) {
  if (-not (Get-Command $name -ErrorAction SilentlyContinue)) {
    throw "Command '$name' not found. Install it and retry."
  }
}

Write-Host "[1/6] Checking prerequisites..." -ForegroundColor Cyan
Assert-Command node
Assert-Command npm

Write-Host "Node: $(node -v)" -ForegroundColor DarkGray
Write-Host "NPM : $(npm -v)" -ForegroundColor DarkGray

Write-Host "[2/6] Installing root dependencies..." -ForegroundColor Cyan
npm ci

Write-Host "[3/6] Installing backend dependencies + building backend..." -ForegroundColor Cyan
Push-Location "backend"
  npm ci
  npm run prisma:generate
  npm run prisma:init-template
  npm run build
Pop-Location

Write-Host "[4/6] Building Electron distributables (nsis + portable)..." -ForegroundColor Cyan
npm run build

Write-Host "[5/6] Generating checksums..." -ForegroundColor Cyan
try {
  npm run release:checksums:win
} catch {
  Write-Host "Checksum step failed (non-blocking): $($_.Exception.Message)" -ForegroundColor Yellow
}

Write-Host "[6/6] Done. Output in .\\dist" -ForegroundColor Green
Get-ChildItem -Path "dist" -Recurse -Filter "*.exe" | Select-Object FullName, Length
